package com.ssss.smallScaleShiftScheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmallScaleShiftSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmallScaleShiftSchedulerApplication.class, args);
	}

}
